# Copy Chrome Extension

This is a Chrome browser extension that automatically monitors and saves all text content you copy in the browser to a text file.

## 功能特点

- 自动捕获浏览器中的复制操作
- 将复制的文本保存到指定目录的文本文件中
- 每条记录带有时间戳，便于追踪
- 简单易用，配置一次即可在后台自动工作

## 安装方法

1. 下载此扩展程序的所有文件
2. 打开Chrome浏览器，进入扩展程序页面（chrome://extensions/）
3. 开启右上角的"开发者模式"
4. 点击"加载已解压的扩展程序"按钮
5. 选择包含此扩展程序文件的文件夹

## 使用方法

1. 安装扩展程序后，点击Chrome工具栏中的扩展图标
2. 在弹出的界面中，点击"选择保存目录